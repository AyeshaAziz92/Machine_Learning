from itertools import product
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
import pickle
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.metrics import plot_roc_curve, accuracy_score, classification_report, recall_score, confusion_matrix


def plot_confusion_matrix(cm, classes,
                        normalize=False,
                        title='Confusion matrix',
                        cmap=plt.cm.Blues):

    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes)
    plt.yticks(tick_marks, classes)

    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    else:
        pass

    thresh = cm.max() / 2.
    for i, j in product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, cm[i, j],
            horizontalalignment="center",
            color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.show()

datasets = pd.read_csv('data.csv')
X = datasets.iloc[:, [0, 1]].values
y = datasets.iloc[:, 2].values
X = np.array([np.append(row, pow(2, math.log(abs(int(row[1])))/2)) for row in X])
X = np.array([np.append(row, math.cos(int(row[1]))) for row in X])
X = np.array([np.append(i, math.sin(int(i[1]))) for i in X])

#################### Model Instance ####################
clf1 = DecisionTreeClassifier(max_depth=50, max_features='auto', random_state=24, splitter='random')
clf2 = KNeighborsClassifier(n_neighbors=30, p=1)
clf3 = SVC(gamma=0.0005, kernel='rbf', probability=True)
clf4 = GradientBoostingClassifier(loss='exponential', learning_rate=0.00346, n_estimators=100, min_samples_split=0.9)
clf5 = LogisticRegression(C=0.0001, n_jobs=-1, random_state=20, max_iter=5000, solver='newton-cg', warm_start=True)
clf6 = LinearRegression()

#################### Split Train Test data ####################
from sklearn.model_selection import train_test_split
X_Train, X_Test, Y_Train, Y_Test = train_test_split(X, y, test_size = 0.40, random_state = 0)
# print(type(X_Test[0]))

#################### Fit ####################
clf1.fit(X_Train, Y_Train)
clf2.fit(X_Train, Y_Train)
clf3.fit(X_Train, Y_Train)
clf4.fit(X_Train, Y_Train)
clf5.fit(X_Train, Y_Train)
clf6.fit(X_Train, Y_Train)

#################### Save Model ####################
dTree = 'DecisionTree.sav'
pickle.dump(clf1, open(dTree, 'wb'))
knn = 'KNN.sav'
pickle.dump(clf1, open(knn, 'wb'))
SVM = 'SVM.sav'
pickle.dump(clf1, open(SVM, 'wb'))
XGB = 'XGBOOST.sav'
pickle.dump(clf1, open(XGB, 'wb'))
logisticRegression = 'LogisticRegression.sav'
pickle.dump(clf1, open(logisticRegression, 'wb'))

#################### Predict ####################
Y_Pred1 = clf1.predict(X_Test)
Y_Pred2 = clf2.predict(X_Test)
Y_Pred3 = clf3.predict(X_Test)
Y_Pred4 = clf4.predict(X_Test)
Y_Pred5 = clf4.predict(X_Test)
Y_Pred6 = clf4.predict(X_Test)

#################### Accuracy Score ####################
score1 = accuracy_score(Y_Test, Y_Pred1)
score2 = accuracy_score(Y_Test, Y_Pred2)
score3 = accuracy_score(Y_Test, Y_Pred3)
score4 = accuracy_score(Y_Test, Y_Pred4)
score5 = accuracy_score(Y_Test, Y_Pred5)
score5 = accuracy_score(Y_Test, Y_Pred6)

#################### Recall ####################
recall1 = recall_score(Y_Test,Y_Pred1)
recall2 = recall_score(Y_Test,Y_Pred2)
recall3 = recall_score(Y_Test,Y_Pred3)
recall4 = recall_score(Y_Test,Y_Pred4)
recall5 = recall_score(Y_Test,Y_Pred5)
recall6 = recall_score(Y_Test,Y_Pred6)

#################### Summary Report ####################
report1 = classification_report(Y_Test, Y_Pred1)
report2 = classification_report(Y_Test, Y_Pred2)
report3 = classification_report(Y_Test, Y_Pred3)
report4 = classification_report(Y_Test, Y_Pred4)
report5 = classification_report(Y_Test, Y_Pred5)
report6 = classification_report(Y_Test, Y_Pred6)
print(report1, '\n', report2, '\n', report3, '\n', report4, '\n', report5, '\n', report6)

#################### Write Report to file ####################
with open("summary report.txt", "w") as f1:
    f1.write('Decision Tree Summary Report')
    f1.write('\n')
    f1.write(str(report1))
    f1.write('\n')
    f1.write('\n')
    f1.write('\n')
    f1.write('K-Nearest Neighbour Summary Report')
    f1.write('\n')
    f1.write(str(report2))
    f1.write('\n')
    f1.write('\n')
    f1.write('\n')
    f1.write('Support Vector Machine Summary Report')
    f1.write('\n')
    f1.write(str(report3))
    f1.write('\n')
    f1.write('\n')
    f1.write('\n')
    f1.write('Gradient Boosting Classifier Report')
    f1.write('\n')
    f1.write(str(report4))
    f1.write('\n')
    f1.write('\n')
    f1.write('\n')
    f1.write('Logistic Regression Summary Report')
    f1.write('\n')
    f1.write(str(report5))
    f1.write('\n')
    f1.write('\n')
    f1.write('\n')
    f1.write('Linear Regression Summary Report')
    f1.write('\n')
    f1.write(str(report6))


#################### Confusion Matrix ####################
cm_plot_labels = ['0','1']
cm1 = confusion_matrix(Y_Test, Y_Pred1)
cm2 = confusion_matrix(Y_Test, Y_Pred2)
cm3 = confusion_matrix(Y_Test, Y_Pred3)
cm4 = confusion_matrix(Y_Test, Y_Pred4)
cm5 = confusion_matrix(Y_Test, Y_Pred5)
cm6 = confusion_matrix(Y_Test, Y_Pred6)
plot_confusion_matrix(cm=cm1, classes=cm_plot_labels, title='Confusion Matrix of Decision Tree')
plot_confusion_matrix(cm=cm2, classes=cm_plot_labels, title='Confusion Matrix of K-Nearest Neighbour')
plot_confusion_matrix(cm=cm3, classes=cm_plot_labels, title='Confusion Matrix of Support Vector Machine')
plot_confusion_matrix(cm=cm4, classes=cm_plot_labels, title='Confusion Matrix of Gradient Boosting Classifier')
plot_confusion_matrix(cm=cm5, classes=cm_plot_labels, title='Confusion Matrix of Logistic Regression')
plot_confusion_matrix(cm=cm6, classes=cm_plot_labels, title='Confusion Matrix of Linear Regression')

#################### ROC Curve ####################
#################### Receiver Operating Characteristic ####################
dtree = plot_roc_curve(clf1, X_Test, Y_Test)
ax = plt.gca()
knn_disp = plot_roc_curve(clf2, X_Test, Y_Test, ax= ax, alpha=0.8)
ax = plt.gca()
svc = plot_roc_curve(clf3, X_Test, Y_Test, ax= ax, alpha=0.8)
ax = plt.gca()
xgboost = plot_roc_curve(clf4, X_Test, Y_Test, ax= ax, alpha=0.8)
ax = plt.gca()
lg = plot_roc_curve(clf5, X_Test, Y_Test, ax= ax, alpha=0.8)
lg.figure_.suptitle("Comparison of ROC curve ")

plt.show()
