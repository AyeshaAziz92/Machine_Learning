import pickle
import numpy as np


dTree = 'DecisionTree.sav'
loaded_model = pickle.load(open(dTree, 'rb'))
x = np.array([2,-80, 4.294, -0.2177698, 0.95551998])
x = x.reshape(x)
print(type(x))
result = loaded_model.score(x,0)
print(result)